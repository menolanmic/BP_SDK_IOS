//
//  ViewController.m
//
//  Copyright (c) 2019 Fenzar Ltd. All rights reserved.
//

#import "ViewController.h"

#define HIDE_LOG  NO

@interface ViewController ()
{
    BPHeadset *headset;
    
    // lastDisconnect is used to detect repeated connection errors
    // so we can avoid getting stuck in a loop of disconnect/reconnect
    NSDate *lastDisconnect;
}

@end

@implementation ViewController
@synthesize connectButton;
@synthesize logTextView;
@synthesize clearButton;
@synthesize logLabel;
@synthesize statusLabel;
@synthesize sdkModeButton;
@synthesize bondableButton;
@synthesize enterpriseView;
@synthesize enterpriseKeyField;
@synthesize enterpriseValueField;
@synthesize enterpriseKeyGetField;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    logTextView.text = nil;
    headset = [BPHeadset sharedInstance];
    [headset addListener:self];
    
    [self checkHeadsetStatus];
    
    logLabel.hidden = clearButton.hidden = logTextView.hidden = HIDE_LOG;
    statusLabel.text = @"";
    NSString *log = [NSString stringWithFormat:@"SDK Version: %@",[[BPHeadset sharedInstance] version]];
    [self addStatus:log];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) checkHeadsetStatus {
    if (headset.connected) {
        [connectButton setTitle:@"Disconnect" forState:UIControlStateNormal];
        sdkModeButton.hidden = NO;
        bondableButton.hidden = NO;
        enterpriseView.hidden = NO;
        if (headset.sdkModeEnabled) {
            [sdkModeButton setTitle:@"Disable SDK Mode" forState:UIControlStateNormal];
        } else {
            [sdkModeButton setTitle:@"Enable SDK Mode" forState:UIControlStateNormal];
        }
        
        if (headset.bondableEnabled == BPBondableEnabled) {
            [bondableButton setTitle:@"Disable Bondable" forState:UIControlStateNormal];
        } else {
            [bondableButton setTitle:@"Enable Bondable" forState:UIControlStateNormal];
        }
    } else {
        [connectButton setTitle:@"Connect" forState:UIControlStateNormal];
        sdkModeButton.hidden = YES;
        bondableButton.hidden = YES;
        enterpriseView.hidden = YES;
    }
}

#pragma mark -
#pragma mark Button Presses

- (IBAction)entSetButtonTouched:(id)sender {
    NSString *key = enterpriseKeyField.text;
    NSString *val = enterpriseValueField.text;
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    f.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *keyNum = [f numberFromString:key];
    [self.view endEditing:YES];
    if (!keyNum) {
        [self showToast:@"You must enter a number for the key"];
        return;
    }
    
    [headset setConfigValue:[keyNum unsignedIntegerValue] value:val];
    [self addStatus:@"Finished setting enterprise key"];
}


- (IBAction)entGetButtonTouched:(id)sender {
    NSString *key = self.enterpriseKeyField.text;
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    f.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *keyNum = [f numberFromString:key];
    [self.view endEditing:YES];
    if (!keyNum) {
        [self showToast:@"You must enter a number for the key"];
        return;
    }

    NSString *value = [headset getConfigValue:[key integerValue]];
    NSString *log = [NSString stringWithFormat:@"Key: %@, Value: %@", key, value];
    [self addStatus:log];
}

- (IBAction)entGetAllButtonTouched:(id)sender {
    [self.view endEditing:YES];
    [self addStatus:@"Getting enterprise keys..."];
    NSDictionary *vals = [headset getConfigValues];
    NSArray *keys = [vals allKeys];
    NSString *log = [NSString stringWithFormat:@"Got %lu keys", (unsigned long)keys.count];
    [self addStatus:log];
    NSSortDescriptor *lowestToHighest = [NSSortDescriptor sortDescriptorWithKey:@"self" ascending:YES];
    NSArray *sortedKeys = [keys sortedArrayUsingDescriptors:[NSArray arrayWithObject:lowestToHighest]];
    
    
    for (NSNumber *key in sortedKeys) {
        NSString *value = [vals objectForKey:key];
        NSString *log = [NSString stringWithFormat:@"Key: %lu, Value: %@", (unsigned long)key.unsignedIntegerValue, value];
        [self addStatus:log];
    }
}

- (IBAction)connectButtonTouched:(id)sender {
    lastDisconnect = nil;
    if (headset.connected) {
        [self addStatus:@"Disconnecting..."];
        [headset disconnect];
    } else {
        [self addStatus:@"Connecting..."];
        [headset connect];
    }
    connectButton.enabled = NO;
}

- (IBAction)clearButtonTouched:(id)sender {
    logTextView.text = nil;
}

- (IBAction)sdkModeButtonTouched:(id)sender {
    if (headset.sdkModeEnabled) {
        [headset disableSDKMode];
    } else {
        [headset enableSDKMode];
    }

}

- (IBAction)bondableButtonTouched:(id)sender {
    if (headset.bondableEnabled == BPBondableEnabled) {
        [headset setBondable:NO];
    } else {
        [headset setBondable:YES];
    }
}

#pragma mark -
#pragma mark BPHeadsetListener methods

- (void) onModeUpdate {
    [self addStatus:@"Headset mode set successfully"];
    [self checkHeadsetStatus];
}

- (void) onConnectProgress:(BPConnectProgress)status {
    switch (status) {
        case BPConnectProgressStarted:
            [self addStatus:@"Started connecting..."];
            break;
        case BPConnectProgressScanning:
            [self addStatus:@"Scanning for headsets..."];
            break;
        case BPConnectProgressFound:
            [self addStatus:@"Headset Found..."];
            break;
        case BPConnectProgressReading:
            [self addStatus:@"Reading headset values..."];
            break;

        default:
            break;
    }
}

- (void) onModeUpdateFailure:(BPModeUpdateError)error {
    [self addStatus:@"Headset mode set error"];
    [self checkHeadsetStatus];
}

- (void) onConnect {
    NSString *msg = [NSString stringWithFormat:@"Headset (%@) connected, current mode: %ld", headset.friendlyName, (long)headset.buttonMode];
    [self addStatus:msg];
}

- (void) onValuesRead {
    NSString *fw = [headset firmwareVersion];
    if (fw == nil) {
        fw = @"Unknown";
    }
    NSString *msg = [NSString stringWithFormat:@"Finished reading headset values, firmware version: %@", fw];
    [self addStatus:msg];
    msg = [NSString stringWithFormat:@"Proximity state: %ld", (long)headset.proximityState];
    [self addStatus:msg];
    msg = [NSString stringWithFormat:@"Bondable: %ld", (long)headset.bondableEnabled];
    [self addStatus:msg];
    msg = [self describeMode];
    [self addStatus:msg];
    [self checkHeadsetStatus];
    connectButton.enabled = YES;
    lastDisconnect = nil;
}

- (void) onConnectFailure:(BPConnectError)reasonCode {
    switch (reasonCode) {
        case BPConnectErrorBluetoothDisabled:
            [self addStatus:@"Headset failed to connect - Bluetooth Disabled"];
            break;
        case BPConnectErrorSDKTooOld:
            [self addStatus:@"Headset failed to connect - SDK is too old for the headset"];
            break;
        case BPConnectErrorFirmwareTooOld:
            [self addStatus:@"Headset failed to connect - Firmware too old"];
            break;
        case BPConnectErrorUnknown:
        default:
            [self addStatus:@"Headset failed to connect - unknown reason"];
            break;
    }
    [self checkHeadsetStatus];
    connectButton.enabled = YES;
}

- (void) onDisconnect {
    [self addStatus:@"Headset disconnected"];
    [self checkHeadsetStatus];
    connectButton.enabled = YES;
    if (lastDisconnect) {
        NSTimeInterval diff = fabs([lastDisconnect timeIntervalSinceNow]);
        if (diff < 3) {
            lastDisconnect = nil;
            [headset disconnect];
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error"
                                                                           message:@"Headset was disconnected, possibly due to a bonding error. Try unpairing the device and pairing again."
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil];
            [alert addAction:cancel];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    lastDisconnect = [NSDate new];
}

- (void) onTap:(BPButtonID) buttonID {
    [self addStatus:@"Headset onSingleTap"];
    [self showToast:@"Single Tap"];
}

- (void) onDoubleTap:(BPButtonID) buttonID {
    [self addStatus:@"Headset onDoubleTap"];
    [self showToast:@"Double Tap"];
}

- (void) onLongPress:(BPButtonID)buttonID {
    [self addStatus:@"Headset onButtonLongPress"];
    [self showToast:@"Long Press"];
}

- (void) onProximityChanged:(BPProximityState)proximityState {
    
    NSString *status = [NSString stringWithFormat:@"Headset proximity changed: %ld", (long)proximityState];
    [self addStatus:status];
}


- (void) onButtonDown:(BPButtonID) buttonID {
    NSString *status = [NSString stringWithFormat:@"Headset onButtonDown"];
    [self addStatus:status];
    self.view.backgroundColor = [UIColor greenColor];
}

- (void) onButtonUp:(BPButtonID) buttonID {
    NSString *status = [NSString stringWithFormat:@"Headset onButtonUp"];
    [self addStatus:status];
    self.view.backgroundColor = [UIColor whiteColor];
}


#pragma mark -
#pragma mark On Screen Logging

- (void) showToast:(NSString *) text {
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:nil
                                 message:text
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    int duration = 2; // seconds
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, duration * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [alert dismissViewControllerAnimated:YES completion:nil];
    });
}

- (void) setStatus:(NSString *)text {
    statusLabel.text = text;
    return;
}

- (void) addStatus:(NSString *)text {
    if (HIDE_LOG) {
        statusLabel.text = text;
        return;
    }
    NSLog(@"%@", text);
    
    NSString *oldText = logTextView.text;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    [dateFormatter setDateFormat:@"HH:mm:ss.SSS"];
    NSDate *now = [NSDate date];
    NSString *timestamp = [dateFormatter stringFromDate:now];
    
    NSString *newLine = [NSString stringWithFormat:@"%@: %@", timestamp, text];
    
    if (oldText && oldText.length > 0) {
        oldText = [oldText stringByAppendingString:@"\n"];
    }   
    
    NSString *newText = [oldText stringByAppendingString:newLine];
    logTextView.text = newText;
    NSRange range = NSMakeRange(logTextView.text.length - 1, 1);
    [logTextView scrollRangeToVisible:range];
}

- (NSString *) describeMode {
    NSString *description = nil;
    BPButtonMode mode = headset.buttonMode;
    BOOL sdkEnabled = headset.sdkModeEnabled;
    NSString *appID = headset.appKey;
    NSString *appName = headset.appName;
    NSString *speedDial = headset.speedDialNumber;
    
    if (sdkEnabled) {
        description = [NSString stringWithFormat:@"SDK Mode, App Name: %@", appName];
        return description;
    }
    
    switch (mode) {
        case BPButtonModeApp:
            description = [NSString stringWithFormat:@"App Mode, App ID: %@, App Name: %@", appID, appName];
            break;
        case BPButtonModeMute:
            description = [NSString stringWithFormat:@"Mute Mode"];
            break;
        case BPButtonModeSpeedDial:
            description = [NSString stringWithFormat:@"Speed Dial Mode (%@)", speedDial];
            break;
        default:
            description = [NSString stringWithFormat:@"Unknown Mode (%ld)", (long)mode];
            break;
    }
    return description;
}


@end
